# articlespinner
This is a simple and effective article spinner. This spinner is very relatable to the popular website: spinbot.com

This is an open source project feel free to pull the code and update the dictionary.php file.
